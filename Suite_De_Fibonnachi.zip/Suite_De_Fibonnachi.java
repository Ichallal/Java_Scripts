package exo01.java;

import java.util.Scanner;

public class exo03 {
	public static int elmSuite(int m) {
		 if (m == 0) {
	        return 0;
	    } else if (m == 1) {
	        return 1;
	    } else {
	        int U0 = 0;
	        int U1 = 1;
	        int elm = 0;
	        for (int i = 2; i <= m; i++) { 
	        	elm = (U0 + U1) * (U0 + U1);
	            U0 = U1;
	            U1 = elm ;
	        }
	        return elm;
	    }
	}
	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in)) {
			System.out.print("veuillez entrer la valeur de n : ");

			int n = s.nextInt();
			int somme=elmSuite(n);
			
			System.out.print("le  " + n + "eme element de la suite est :"+ somme);
		}
	}
}