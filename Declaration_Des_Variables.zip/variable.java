package exo01.java;
import java.util.Scanner;
public class variable {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double i=5.25889444;
		String mot11 = "\t";
		String nom = "John Doe";
		char mia='l';
	    boolean b=true;
	    float f=(float) 1.2598;
		int[] Tab1 = {12,0,5,6, 3,1};
		int[][] intTabMulti1 = {{12, 1, 4}, {0, 5, 9}};
		boolean bb=false;
		String[] tableauChaines = {"Bonjour", "monde", "!"};
		Scanner scanner = new Scanner(System.in);
		int s=scanner.nextInt();
		int[] nums = {1, 2, 3, 4, 5};
        String[] names = {"Alice", "Bob", "Charlie", "David"};
	}
}