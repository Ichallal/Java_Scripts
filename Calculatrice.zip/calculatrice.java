package exo01.java;
import java.util.Scanner;
public class calculatrice {
    public int somme(int c, int d) {
        return c + d;
    }

    public int soustraction(int c, int d) {
        return c - d;
    }
    public int produit(int c, int d) {
        return c * d;
    }
    public int division(int c, int d) {
        return c / d;
    }
    public int reste(int c, int d) {
        return c % d;
    }
    public static void main(String[] args) {
        try (Scanner s = new Scanner(System.in)) {
            System.out.println("veuillez entrer la valeur de a: ");
            int a = s.nextInt();
            System.out.println("veuillez entrer la valeur de b : ");
            int b = s.nextInt();

            calculatrice calc = new calculatrice();

            System.out.println("veuillez introduire 1 si vous voulez loperation addition 2 soustraction 3 multiplication et 4 pour division  ");
            int m=s.nextInt();
            switch (m) {
            case 1: System.out.println("la somme de " + a + " et " + b + " est " + calc.somme(a, b)); break;
            case 2: System.out.println("la soustraction de " + a + " et " + b + " est " + calc.soustraction(a, b));break;
            case 3: System.out.println("le produit de " + a + " et " + b + " est " + calc.produit(a, b));break;
            case 4:System.out.println("la division de " + a + " et " + b + " est " + calc.produit(a, b));break;
            
            }
            
            System.out.println("veuillez introduire un chiffre paire si vous voulez refaire et autre sinon ");

            int t = s.nextInt();
            while (t%2==0) {
   
            System.out.println("veuillez entrer la valeur de a: ");
            a = s.nextInt();
            System.out.print("veuillez entrer la valeur de b : ");
            b = s.nextInt();
            System.out.println("veuillez introduire 1 si vous voulez loperation addition 2 soustraction 3 multiplication et 4 pour division  ");
            m=s.nextInt();
            switch (m) {
            case 1: System.out.println("la somme de " + a + " et " + b + " est " + calc.somme(a, b)); break;
            case 2: System.out.println("la soustraction de " + a + " et " + b + " est " + calc.soustraction(a, b));break;
            case 3: System.out.println("le produit de " + a + " et " + b + " est " + calc.produit(a, b));break;
            case 4:System.out.println("la division de " + a + " et " + b + " est " + calc.produit(a, b));break;
            }
            System.out.println("veuillez introduire un chiffre paire si vous voulez refaire et autre sinon ");
            t=s.nextInt();
            }
            
        }
    }
}
