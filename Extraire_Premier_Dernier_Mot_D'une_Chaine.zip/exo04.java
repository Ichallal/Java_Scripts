package exo01.java;

import java.util.Scanner;

public class exo04 {
	static String mot1(String txt ) {
		 String mot11 = ""; //on initialise a vide au debut puis on lui rajoute apres dans les autre instruction 
		 int j;
		for (j = 0; j < txt.length(); j++) {
            if (txt.charAt(j) != ' ') {  // on parcours dans la chaine jusqu'a arriver a un espace et on arrete 
                mot11 += txt.charAt(j);
            } else {
                break;
            }
        }
		return(mot11);
		}
	//je prend la question avnt et on vas de la fin vers le debut 
	static String motDernier(String txt ) {
		 String mot11 = ""; //on initialise a vide au debut puis on lui rajoute apres dans les autre instruction 
		 int j;
		for (j = txt.length()-1; j >=0; j--) {
           if (txt.charAt(j) != ' ') {  // on parcours dans la chaine jusqu'a arriver a un espace et on arrete 
               mot11 += txt.charAt(j);
           } else {
               break;
           }
       }
		return(mot11);
		}
	
	
	
	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
			Scanner s = new Scanner(System.in)) {
				System.out.print("Entrez un texte : ");
				String chaine = s.nextLine();
      
				
				System.out.println("Premier mot : " + mot1(chaine));
		
				
				String ss=motDernier(chaine);
				 //ayant recuperer le mot mais inverser je prend linitiatiuve de linverser moi aussi
				int i;
				String  newStr="";     //je recuperer le mot mais inverser je prend linitiatiuve de linverser moi aussi
				for( i = ss.length() - 1; i >= 0; i--)
				{
				   newStr = newStr + ss.charAt(i);
				}
				System.out.println("dernier mot : " +newStr);
			}
	    }
	        
	    }
	

