package exo01.java;
import java.util.Scanner;
public class random {
    
	public static void main(String[] args) {
		int nombreAleatoire = 0 + (int)(Math.random() * ((100 - 0) + 1));
		int nombreEssais = 1;
		System.out.println("Veuillez entrer un chiffre entre 0 et 100");
		while(nombreEssais < 7) {
			Scanner s = new Scanner(System.in);
			int a = s.nextInt();
			if(a == nombreAleatoire) {
				System.out.println("Bravo, tu as trouvé après " + nombreEssais +" essais différents.");
				break;
			}
			else if (a < nombreAleatoire ){
				System.out.println("Le chiffre que tu as choisi est plus petit.");
				nombreEssais++;
			}
			else if(a > nombreAleatoire) {
				System.out.println("Le chiffre que tu as choisi est plus grand.");
				nombreEssais++;
			}
		}
		if (nombreEssais == 7) {
			System.out.println("Dommage, tu as utilisé tous tes essais. Le chiffre était " + nombreAleatoire + ".");
		}
	}}
